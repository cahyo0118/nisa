// "use strict";
// $(document).ready(function () {
// // Slide navbar menu
//   var toggleMenuSelector = $('.toggle-menu');
//   var toggleMenuTarget = toggleMenuSelector.data('target');
//
//   $('.toggle-menu').click(() => {
//     console.log('Selector', toggleMenuTarget);
//     var toggleMenuTargetSelector = $(`div[id^='${toggleMenuTarget}']`);
//     toggleMenuTargetSelector.toggle('slide');
//   });
// });
