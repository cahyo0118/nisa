import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-account-navbar-mobile',
  templateUrl: './account-navbar-mobile.component.html',
  styleUrls: ['./account-navbar-mobile.component.css']
})
export class AccountNavbarMobileComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
