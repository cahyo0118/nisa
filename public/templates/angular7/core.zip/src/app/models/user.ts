export class User {

    id: number;

    name: string;

    email: string;

    address: string;

    oraganization: string;

    about: string;

    password: string;

    created_at: any;

    updated_at: any;

}
