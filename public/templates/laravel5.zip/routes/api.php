<?php

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
 */

Route::group(array('prefix' => 'v1', 'middleware' => ['cors']), function () {

    Route::post('register', 'api\RegisterController@register');

    Route::get('unauthentication', [
        'uses' => 'api\UserProfileController@handleUnauthentication',
        'as' => 'login',
    ]);

});

Route::get('tayo', [
    'uses' => 'api\UserProfileController@testReq',
]);

Route::group(array('prefix' => 'v1', 'middleware' => ['auth:api', 'cors']), function () {

    // User Profile
    Route::get('me', 'api\UserProfileController@getCurrentUser');

    Route::get('me/auth', 'api\UserProfileController@checkAuth');

    Route::put('me/update', 'api\UserProfileController@updateCurrentUser');

    Route::put('me/update/password', 'api\UserProfileController@updateCurrentUserPassword');

    Route::post('me/update/photo', 'api\UserProfileController@updateCurrentUserPhoto');

    Route::post('me/logout', 'api\UserProfileController@logout');

    // Users Routes
    Route::get('users', [
        'middleware' => 'permission:user_read',
        'uses' => 'api\UserController@getAll',
    ]);

    Route::get('users/search/{keyword}', [
        'middleware' => 'permission:user_read',
        'uses' => 'api\UserController@getAllByKeyword',
    ]);

    Route::get('users/{id}', [
        'middleware' => 'permission:user_read',
        'uses' => 'api\UserController@getOne',
    ]);

    Route::post('users/store', [
        'middleware' => 'permission:user_create',
        'uses' => 'api\UserController@store',
    ]);

    Route::put('users/{id}/update', [
        'middleware' => 'permission:user_update',
        'uses' => 'api\UserController@update',
    ]);

    Route::delete('users/{id}/delete', [
        'middleware' => 'permission:user_delete',
        'uses' => 'api\UserController@destroy',
    ]);

    Route::delete('users/delete/multiple', [
        'middleware' => 'permission:user_delete',
        'uses' => 'api\UserController@deleteMultiple',
    ]);




});
