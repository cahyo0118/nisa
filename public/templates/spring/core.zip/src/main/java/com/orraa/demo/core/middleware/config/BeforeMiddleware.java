package com.orraa.demo.core.middleware.config;

public @interface BeforeMiddleware {
}
