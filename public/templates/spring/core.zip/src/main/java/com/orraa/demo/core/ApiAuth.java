package com.orraa.demo.core;

public class ApiAuth {

    public static boolean checkToken(String token) {

        if (token != null) {

        }

        return false;
    }

    public static String doLogin(String username, String password) {

        return "";
    }
}
