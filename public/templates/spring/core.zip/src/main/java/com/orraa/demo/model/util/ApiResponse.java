//package com.orraa.demo.model.util;

//public class ApiResponse {
//    public int success = 1;
//    public int status = 200;
//    public String title = "success";
//    public String message = "Successfully executed action";
//    public Object data;
//
//    public ApiResponse() {
//    }
//
//    public ApiResponse(Object data, int success, int status) {
//        this.success = success;
//        this.status = status;
//        this.data = data;
//    }
//
//    public ApiResponse(Object data, int success, String title, String message) {
//        this.success = success;
//        this.data = data;
//        this.title = title;
//        this.message = message;
//    }
//}
