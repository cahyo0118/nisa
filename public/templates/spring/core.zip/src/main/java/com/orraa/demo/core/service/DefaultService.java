package com.orraa.demo.core.service;

public interface DefaultService {

    public boolean pre();
    public void post();
}
